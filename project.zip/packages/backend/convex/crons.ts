import { cronJobs } from "./_generated/server";
import { internal } from "./_generated/api";

// Schedule the GitHub + AI sync to run every hour automatically.
cronJobs.interval(
  "hourly GitHub sync",
  { minutes: 60 },
  internal.github.syncGitHubData,
  {},
);
